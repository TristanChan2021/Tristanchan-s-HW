﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Tristan_Pong
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                playerOne.Score = 0;
                playerTwo.Score = 0;
                Console.CursorVisible = false;
                Console.WindowHeight = 30;
                Console.WindowWidth = 100;
                Console.BufferHeight = 30;
                Console.BufferWidth = 100;
                var title = "Pong";
                Console.CursorLeft = Console.WindowWidth / 2 - title.Length / 2;
                Console.WriteLine(title);
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("player one's Controls : \n\n" +
                                  "W - Up\n" +
                                  "S - Down\n" );
                var playerTwoControlTitle = "Player Two's controls:";
                var playerTwoControlTileCursorLeftPosition = Console.BufferWidth - playerTwoControlTitle.Length;
                Console.CursorTop = 1;
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.CursorLeft = playerTwoControlTileCursorLeftPosition;
                Console.WriteLine(playerTwoControlTitle);
                Console.CursorTop = 3;
                Console.CursorLeft = playerTwoControlTileCursorLeftPosition;
                Console.WriteLine("Up Arrow - Up");
                Console.CursorLeft = playerTwoControlTileCursorLeftPosition;
                Console.WriteLine("Down Arrow - Down");
                Console.ReadLine();
                Console.Clear();

                while (playerTwo.Score <= 2 && playerOne.Score <= 2)
                {
                    
                    playerOne.position.x = 4;
                    playerOne.position.y = Console.WindowHeight / 2 - playerLength / 2;
                    playerTwo.position.x = Console.WindowWidth - 4;
                    playerTwo.position.y = Console.WindowHeight / 2 - playerLength / 2;
                    moveball.position.x = Console.WindowWidth / 2;
                    moveball.position.y = Console.WindowHeight / 2;
                    moveball.direction.x = 2;
                    moveball.direction.y = 1;

                    while (true)
                    {
                        
                        if (Console.KeyAvailable)
                        {
                            var key = Console.ReadKey(true);
                            if (key.Key == ConsoleKey.W)
                            {
                                playerOne.Direction = vector2.Up;
                                playerOne.position += playerOne.Direction;
                                if (playerOne.position.y < 0)
                                {
                                    playerOne.position = new vector2(playerOne.position.x, 0);
                                }
                                Console.Clear();
                            }
                            if (key.Key == ConsoleKey.S)
                            {
                                playerOne.Direction = vector2.Down;
                                playerOne.position += playerOne.Direction;
                                if (playerOne.position.y >= Console.WindowHeight - 6)
                                {
                                    playerOne.position = new vector2(4, Console.WindowHeight - 7);
                                }
                                Console.Clear();
                            }
                            if (key.Key == ConsoleKey.UpArrow)
                            {
                                playerTwo.Direction = vector2.Up;
                                playerTwo.position += playerTwo.Direction;
                                if (playerTwo.position.y < 0)
                                {
                                    playerTwo.position = new vector2(playerTwo.position.x, 0);
                                }
                                Console.Clear();
                            }
                            if (key.Key == ConsoleKey.DownArrow)
                            {
                                playerTwo.Direction = vector2.Down;
                                playerTwo.position += playerTwo.Direction;
                                if (playerTwo.position.y >= Console.WindowHeight - 6)
                                {
                                    playerTwo.position = new vector2(playerTwo.position.x, Console.WindowHeight - 6);
                                }
                                Console.Clear();
                            }
                        }
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.CursorTop = 2;
                        Console.CursorLeft = Console.WindowWidth / 2;
                        Console.WriteLine(playerOne.Score + ":" + playerTwo.Score);
                        for (int i = 0; i < playerLength; i++)
                        {
                            DrawPlayer(playerOne.position.x, playerOne.position.y + i, '|', ConsoleColor.Yellow);
                            DrawPlayer(playerTwo.position.x, playerTwo.position.y + i, '|', ConsoleColor.White);
                        }
                        DrawBall(moveball.position.x, moveball.position.y, moveball.direction.x, moveball.direction.y, 'O', ConsoleColor.Blue);
                        moveball.position += moveball.direction;
                        Console.Clear();
                        if (moveball.position.y == Console.WindowHeight - 1 || moveball.position.y == 1)
                        {
                            moveball.direction = new vector2(moveball.direction.x, -moveball.direction.y);
                        }
                        for (int i = 0; i < playerLength; i++)
                        {
                            if (moveball.position.x == playerTwo.position.x && moveball.position.y == playerTwo.position.y + i)
                            {
                                moveball.direction = new vector2(-moveball.direction.x, moveball.direction.y);
                            }
                            if (moveball.position.x == playerOne.position.x && moveball.position.y == playerOne.position.y + i)
                            {
                                moveball.direction = new vector2(-moveball.direction.x, moveball.direction.y);
                            }
                        }
                        if (moveball.position.x >= Console.WindowWidth)
                        {
                            playerOne.Score++;
                            break;
                        }
                        if (moveball.position.x <= 0)
                        {
                            playerTwo.Score++;
                            break;
                        }
                    }
                }
                if (playerOne.Score == 3)
                {
                    Console.CursorTop = Console.WindowHeight / 2;
                    string end = "playerOne Win!";
                    Console.CursorLeft = Console.WindowWidth / 2 - end.Length/2;
                    Console.WriteLine(end);
                }
                else if (playerTwo.Score == 3)
                {
                    Console.CursorTop = Console.WindowHeight / 2;
                    string end = "playerTwo Win!";
                    Console.CursorLeft = Console.WindowWidth / 2 - end.Length / 2;
                    Console.WriteLine(end);
                }
                Console.ReadLine();
                Console.Clear();
            }
        }
        public static int playerLength = 6;
        private static void DrawPlayer(int positionX, int positionY, char playerSymbol, ConsoleColor color)
        {

            Console.ForegroundColor = color;


            Console.SetCursorPosition(positionX, positionY);
            Console.Write(playerSymbol);
        }
        public struct vector2
        {
            public int x;
            public int y;

            public vector2(int x, int y)
            {
                this.x = x;
                this.y = y;
            }
            public static readonly vector2 Up = new vector2(0, -1);
            public static readonly vector2 Down = new vector2(0, 1);

            public static vector2 operator +(vector2 v1, vector2 v2)
            {
                return new vector2(v1.x + v2.x, v1.y + v2.y);
            }
            public static vector2 operator -(vector2 v)
            {
                return new vector2(-v.x, -v.y);
            }
            public static bool operator ==(vector2 v1, vector2 v2)
            {
                return (v1.x == v2.x && v1.y == v2.y);
            }
            public static bool operator !=(vector2 v1, vector2 v2)
            {
                return (v1.x != v2.x || v1.y != v2.y);
            }
        }
        public class Player
        {
            public vector2 Direction;
            public vector2 position;
            public int Score = 0;
            public Dictionary<ConsoleKey, vector2> InputDirections;
        }
        private static Player playerOne = new Player()
        {

            InputDirections = new Dictionary<ConsoleKey, vector2>()
            {
                {
                    ConsoleKey.W,vector2.Up
                } ,
                {
                    ConsoleKey.S,vector2.Down
                },
            }
        };
        private static Player playerTwo = new Player()
        {

            InputDirections = new Dictionary<ConsoleKey, vector2>()
            {
                {
                    ConsoleKey.UpArrow,vector2.Up
                } ,
                {
                    ConsoleKey.DownArrow,vector2.Down
                },
            }
        };

        //public static int speedX = -1;
        //public static int speedy = 1;
        public class Ball
        {
            public vector2 direction;
            public vector2 position;
        }
        public static Ball moveball = new Ball()
        {
            direction = new vector2(1, 0)
        };

        private static void DrawBall(int positionX, int positionY, int directionX, int directionY, char Symbol, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.SetCursorPosition(positionX, positionY);
            Console.Write(Symbol);
            int timescale = 80;
            Thread.Sleep(timescale);
            
        }
    }
}

